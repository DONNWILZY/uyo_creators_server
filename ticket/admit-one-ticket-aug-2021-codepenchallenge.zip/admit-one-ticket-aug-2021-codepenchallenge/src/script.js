// Loosely inspired by https://dribbble.com/shots/9165032-Luke-Combs-Ticket-Stub

// See my speed code of this on YouTube
// https://youtu.be/SukP7Z33Ktk